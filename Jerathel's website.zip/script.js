document.getElementById("foot01").innerHTML =
"<p>&copy;  " + new Date().getFullYear() + " Classicalpieces. All rights reserved.</p>";
document.getElementById("nav01").innerHTML =
 "<ul id='menu'>" +
"<li><a href='jumbotron.html'>Home</a></li>" +
 "<li><a href='data.html'>Links</a></li>" +
 "<li><a href='aboutus.html'>About Us</a></li>" +
 "<li><a href='form.html'>Submit a form</li>" +
 
 "</ul>"; 
 